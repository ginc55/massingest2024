﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomObjectImport.WorkClas.HelperObjects
{
    class LanguageListO
    {
        public int indexInList { get; set; }

        public List<string> tempLanguageList { get; set; }

    }
}
