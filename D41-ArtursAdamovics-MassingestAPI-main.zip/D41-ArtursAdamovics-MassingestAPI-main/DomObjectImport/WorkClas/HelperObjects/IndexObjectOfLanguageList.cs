﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomObjectImport.WorkClas.HelperObjects
{
    class IndexObjectOfLanguageList
    {
        public int sourceInt { get; set; }
        public int scientificCommentInt { get; set; }
        public int descriptionInt { get; set; }
        public int tableOfContentsInt { get; set; }
        public int abstractInt { get; set; }
        public int alternativeTitleInt { get; set; }

        public int formatExtentInt { get; set; }


    }
}
