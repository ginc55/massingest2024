﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomObjectImport.WorkClas
{
    class DigitalObjectMetadataSubfield
    {
        public string ElementName { get; set; }

        public string Value { get; set; }
        
    }
}
