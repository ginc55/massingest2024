﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomObjectImport.WorkClas
{
    public class AuthorizationResponse
    {
        public bool Result
        {
            get; set;
        }

    }

     class Authlogin
    {

        static public string Username
        {
            get; set;
        }

       static public string Password
        {
            get; set;


        }

    }

    class AuthloginnotST
    {

         public string Username
        {
            get; set;
        }

         public string Password
        {
            get; set;


        }

    }

}
